/**
 * Utility to transform various social media and video URLs into embeddable format.
 */
export function getEmbedUrl(url: string | undefined): string | null {
  if (!url) return null;

  // Instagram Post/Reel
  if (url.includes('instagram.com/p/') || url.includes('instagram.com/reel/') || url.includes('instagram.com/reels/')) {
    // Remove query params and ensure it ends with /embed/
    const base = url.split('?')[0];
    return `${base.endsWith('/') ? base : base + '/'}embed/`;
  }

  // YouTube
  if (url.includes('youtube.com/watch?v=')) {
    const videoId = url.split('v=')[1].split('&')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }
  if (url.includes('youtu.be/')) {
    const videoId = url.split('youtu.be/')[1].split('?')[0];
    return `https://www.youtube.com/embed/${videoId}`;
  }

  // TikTok
  if (url.includes('tiktok.com/')) {
    // TikTok embeds are more complex, but we can try basic iframe link if available
    // or just return the URL if it's already an embed link.
  }

  return url;
}

/**
 * Checks if a URL is an image type (base64 or standard extension)
 */
export function isImageUrl(url: string | undefined): boolean {
  if (!url) return false;
  if (url.startsWith('data:image/')) return true;
  return /\.(jpg|jpeg|png|webp|avif|gif|svg)$/i.test(url.split('?')[0]);
}

/**
 * Checks if a URL is a video type
 */
export function isVideoUrl(url: string | undefined): boolean {
  if (!url) return false;
  if (url.startsWith('data:video/')) return true;
  if (url.includes('instagram.com/') || url.includes('youtube.com/') || url.includes('youtu.be/')) return true;
  return /\.(mp4|webm|ogg|mov)$/i.test(url.split('?')[0]);
}
