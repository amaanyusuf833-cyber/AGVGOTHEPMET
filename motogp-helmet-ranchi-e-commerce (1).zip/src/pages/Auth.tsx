import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail,
  confirmPasswordReset,
  verifyPasswordResetCode,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, ArrowRight, Loader2, AlertCircle, CheckCircle2, Chrome } from 'lucide-react';

type AuthMode = 'login' | 'signup' | 'forgot-password' | 'reset-password' | 'mobile-login';

export default function Auth() {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [sentOtp, setSentOtp] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [oobCode, setOobCode] = useState<string | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  const handleSendOTP = async () => {
    if (mobile.length !== 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }

    setError(null);
    setLoading(true);
    
    // Generate 6-digit OTP
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    try {
      const response = await fetch('/api/whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: mobile,
          message: `Your AGV GOD Verification Code: ${code}. Do not share this with anyone. Code expires in 5 minutes.`
        })
      });

      const data = await response.json();
      if (data.success) {
        setSentOtp(code);
        setSuccess(`OTP sent to ${mobile} via WhatsApp`);
      } else {
        // If Twilio fails (e.g. not configured), we'll do a mock behavior for development
        console.warn('Twilio failed, using mock OTP for development');
        setSentOtp(code);
        setSuccess(`[DEV MODE] OTP: ${code} (WhatsApp notification failed)`);
      }
    } catch (err: any) {
      console.error(err);
      setError('Failed to send OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp !== sentOtp) {
      setError('Invalid OTP. Please check and try again.');
      return;
    }

    setLoading(true);
    setSuccess('OTP Verified!');
    
    // In a real app, we would use Firebase custom tokens or signInWithPhoneNumber
    // For now, we simulate a successful login by navigating
    setTimeout(() => {
      const params = new URLSearchParams(location.search);
      const redirectTo = params.get('redirect') || '/';
      navigate(redirectTo);
    }, 1000);
  };

  useEffect(() => {
    // Check for password reset code in URL
    const params = new URLSearchParams(location.search);
    const code = params.get('oobCode');
    const urlMode = params.get('mode');

    if (code && urlMode === 'resetPassword') {
      setOobCode(code);
      setMode('reset-password');
      
      // Verify code is still valid
      verifyPasswordResetCode(auth, code)
        .then(() => {
          // No need to set email, confirmPasswordReset only needs oobCode
        })
        .catch(() => {
          setError('This password reset link is invalid or has expired.');
          setMode('login');
        });
    }
  }, [location]);

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    const provider = new GoogleAuthProvider();
    const params = new URLSearchParams(location.search);
    const redirectTo = params.get('redirect') || '/';

    try {
      await signInWithPopup(auth, provider);
      navigate(redirectTo);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    const params = new URLSearchParams(location.search);
    const redirectTo = params.get('redirect') || '/';

    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email, password);
        navigate(redirectTo);
      } else if (mode === 'signup') {
        try {
          await createUserWithEmailAndPassword(auth, email, password);
          // In a real app, you might want to update the profile with the name
          // await updateProfile(auth.currentUser!, { displayName: name });
          navigate(redirectTo);
        } catch (err: any) {
          if (err.code === 'auth/email-already-in-use') {
            setError('This email is already registered. Please login instead or use a different email.');
            setMode('login');
          } else {
            setError(err.message);
          }
          return;
        }
      } else if (mode === 'forgot-password') {
        try {
          const actionCodeSettings = {
            // URL to redirect back to. The domain must be whitelisted in the Firebase Console.
            url: window.location.origin + '/auth',
            handleCodeInApp: true,
          };
          await sendPasswordResetEmail(auth, email.trim(), actionCodeSettings);
          setSuccess('Password reset email sent! Please check your inbox and your spam folder.');
          setEmail('');
        } catch (err: any) {
          if (err.code === 'auth/user-not-found') {
            setError('We couldn\'t find an account with that email address. Please check your spelling or sign up.');
          } else if (err.code === 'auth/invalid-email') {
            setError('Please enter a valid email address.');
          } else {
            setError(err.message || 'An error occurred while sending the reset link.');
          }
          return;
        }
      } else if (mode === 'reset-password' && oobCode) {
        if (password !== confirmPassword) {
          setError('Passwords do not match.');
          setLoading(false);
          return;
        }

        try {
          await confirmPasswordReset(auth, oobCode, password);
          setEmail('');
          setPassword('');
          setConfirmPassword('');
          setSuccess('Password has been reset successfully! You can now login with your new password.');
          setMode('login');
        } catch (err: any) {
          setError(err.message || 'Failed to reset password. The link may have expired.');
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-24 px-6 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-brand-accent/5 rounded-full blur-[120px] -z-10 animate-pulse"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-white/5 rounded-full blur-[120px] -z-10 animate-pulse" style={{ animationDelay: '1s' }}></div>

      <motion.div 
        id="login-section"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-brand-black border border-white/5 p-8 md:p-12 shadow-2xl relative"
      >
        <div className="text-center mb-10">
          <h1 className="text-3xl font-display font-bold uppercase tracking-widest mb-2">
            {mode === 'login' ? 'Welcome Back' : mode === 'signup' ? 'Create Account' : mode === 'reset-password' ? 'New Password' : mode === 'mobile-login' ? 'OTP Login' : 'Reset Password'}
          </h1>
          <p className="text-brand-metallic text-xs uppercase tracking-widest font-medium">
            {mode === 'login' ? 'Access your AGV God profile' : 
             mode === 'signup' ? 'Join the elite riders club' : 
             mode === 'mobile-login' ? 'Quick access via WhatsApp' :
             mode === 'reset-password' ? (success ? 'Password successfully changed' : 'Choose a strong new password') : 
             success ? 'Check your inbox for instructions' : 'Enter your email to recover access'}
          </p>
        </div>

        <div className="mb-6">
          <AnimatePresence mode="wait">
            {error && (
              <motion.div 
                key="error"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-brand-accent/10 border border-brand-accent/20 p-4 flex items-start gap-3 text-brand-accent text-xs uppercase tracking-widest font-bold mb-4"
              >
                <AlertCircle size={16} className="shrink-0" />
                <span>{error}</span>
              </motion.div>
            )}

            {success && (
              <motion.div 
                key="success"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-green-500/10 border border-green-500/20 p-4 flex items-start gap-3 text-green-500 text-xs uppercase tracking-widest font-bold mb-4"
              >
                <CheckCircle2 size={16} className="shrink-0" />
                <span>{success}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <AnimatePresence mode="wait">
          {mode === 'mobile-login' ? (
            <motion.div 
              key="mobile-login"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-bold tracking-widest text-brand-metallic ml-1">Mobile Number</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-metallic" size={18} />
                  <input 
                    type="tel" 
                    id="mobile"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    required 
                    className="w-full bg-white/5 border border-white/10 py-4 pl-12 pr-4 text-sm focus:border-brand-accent transition-colors font-mono"
                    placeholder="ENTER 10-DIGIT MOBILE"
                  />
                </div>
              </div>

              {sentOtp ? (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <label className="text-[10px] uppercase font-bold tracking-widest text-brand-metallic ml-1">Verification Code</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-metallic" size={18} />
                      <input 
                        type="number" 
                        id="otp"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value.slice(0, 6))}
                        required 
                        className="w-full bg-white/5 border border-white/10 py-4 pl-12 pr-4 text-sm focus:border-brand-accent transition-colors font-mono tracking-[0.5em]"
                        placeholder="••••••"
                      />
                    </div>
                  </div>
                  <button 
                    type="button"
                    onClick={handleVerifyOTP}
                    disabled={loading}
                    className="w-full bg-brand-accent text-white py-5 font-bold uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 transition-all"
                  >
                    {loading ? <Loader2 className="animate-spin" size={18} /> : <><span>Verify & Proceed</span> <ArrowRight size={16} /></>}
                  </button>
                </motion.div>
              ) : (
                <button 
                  type="button"
                  onClick={handleSendOTP}
                  disabled={loading}
                  className="w-full bg-white/10 border border-white/20 text-white py-5 font-bold uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 hover:bg-white hover:text-brand-black transition-all"
                >
                  {loading ? <Loader2 className="animate-spin" size={18} /> : <><span>Send OTP via WhatsApp</span> <ArrowRight size={16} /></>}
                </button>
              )}
            </motion.div>
          ) : (
            <motion.form 
              key="email-login"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onSubmit={handleSubmit} 
              className="space-y-6"
            >
              {mode === 'signup' && (
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-brand-metallic ml-1">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-metallic" size={18} />
                    <input 
                      type="text" 
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required 
                      className="w-full bg-white/5 border border-white/10 py-4 pl-12 pr-4 text-sm focus:border-brand-accent transition-colors"
                      placeholder="Enter your name"
                    />
                  </div>
                </div>
              )}

              {mode !== 'reset-password' && !(mode === 'forgot-password' && success) && (
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-brand-metallic ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-metallic" size={18} />
                    <input 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required 
                      className="w-full bg-white/5 border border-white/10 py-4 pl-12 pr-4 text-sm focus:border-brand-accent transition-colors"
                      placeholder="ENTER YOUR EMAIL"
                    />
                  </div>
                </div>
              )}

              {mode !== 'forgot-password' && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-[10px] uppercase font-bold tracking-widest text-brand-metallic">
                      {mode === 'reset-password' ? 'New Password' : 'Password'}
                    </label>
                    {mode === 'login' && (
                      <button 
                        type="button"
                        onClick={() => setMode('forgot-password')}
                        className="text-[10px] uppercase font-bold tracking-widest text-brand-accent hover:text-white transition-colors"
                      >
                        Forgot?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-metallic" size={18} />
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required 
                      className="w-full bg-white/5 border border-white/10 py-4 pl-12 pr-4 text-sm focus:border-brand-accent transition-colors"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              {mode === 'reset-password' && (
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-bold tracking-widest text-brand-metallic ml-1">Confirm New Password</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-metallic" size={18} />
                    <input 
                      type="password" 
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required 
                      className="w-full bg-white/5 border border-white/10 py-4 pl-12 pr-4 text-sm focus:border-brand-accent transition-colors"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-brand-accent text-white py-5 font-bold uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-3 group transition-all shadow-[0_0_30px_rgba(255,51,51,0.2)] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <Loader2 className="animate-spin" size={18} />
                ) : (
                  <>
                    <span>
                      {mode === 'login' ? 'Login' : 
                       mode === 'signup' ? 'Join Now' : 
                       mode === 'reset-password' ? 'Reset Password' : 
                       'Send Reset Link'}
                    </span>
                    <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="mt-8 pt-8 border-t border-white/5 flex flex-col gap-4">
          {(mode === 'login' || mode === 'signup') && (
            <button 
              onClick={handleGoogleSignIn}
              className="w-full bg-white/5 border border-white/10 py-4 px-4 flex items-center justify-center gap-3 text-xs font-bold uppercase tracking-widest hover:bg-white hover:text-brand-black transition-all"
            >
              <Chrome size={18} />
              <span>Continue with Google</span>
            </button>
          )}

          <div className="text-center">
            {mode === 'login' ? (
              <div className="flex flex-col gap-4">
                <p className="text-brand-metallic text-[10px] uppercase tracking-[0.15em]">
                  Don't have an account? {' '}
                  <button onClick={() => setMode('signup')} className="text-white hover:text-brand-accent font-bold transition-colors">Sign Up</button>
                </p>
                <button 
                  onClick={() => setMode('mobile-login')} 
                  className="text-brand-accent hover:text-white text-[10px] uppercase font-bold tracking-widest transition-colors underline underline-offset-4"
                >
                  Login with Mobile OTP
                </button>
              </div>
            ) : mode === 'mobile-login' ? (
              <p className="text-brand-metallic text-[10px] uppercase tracking-[0.15em]">
                Prefer email login? {' '}
                <button onClick={() => setMode('login')} className="text-white hover:text-brand-accent font-bold transition-colors">Go Back</button>
              </p>
            ) : (mode === 'signup' || mode === 'forgot-password') ? (
              <p className="text-brand-metallic text-[10px] uppercase tracking-[0.15em]">
                Already a member? {' '}
                <button onClick={() => setMode('login')} className="text-white hover:text-brand-accent font-bold transition-colors">Login</button>
              </p>
            ) : null}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
